
fun main() {
    val students = 1..20
    val shuffledStudents = students.shuffled()
    students.forEach {
        println("$it -> ${shuffledStudents[it - 1]}.kt")
    }
}
